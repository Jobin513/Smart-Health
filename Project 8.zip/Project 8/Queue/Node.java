package Queue;


/**
 * Node.java
 * Implementation of a generalized Node for our Queue
 * 
 * Sung Kim (modified with annotations from Carrano/Prichard)
 */
public class Node
{
    Object item;    //the data item stored in the Node
    Node next;      //pointer to next Node
    
    //constructor - save data into Node; initialize next to null
    public Node(Object data)
    {
        item = data;
        next = null;
    }
}
