package Tree;
package Queue;
import Queue.*;
/**
 * BinaryTree.java
 * Implementation of a reference-based binary tree
 * 
 * Sung Kim (modified from Carrano/Prichard)
 */
public class BinaryTree
{
    private TreeNode root;  // head of the list

    //constructor - create an empty binary tree
    public BinaryTree()
    {
        root = null;

    }

    //isEmpty() - return true if tree is empty, false otherwise
    public boolean isEmpty()
    {
        return (root == null);
    }

    //deleteTree() - remove all items from tree
    public void deleteList()
    {
        root = null;
    }

    //binSearch() - wrapper method to call the recursive bin search helper method
    public TreeNode binSearch(Object key)
    {
        if (isEmpty())
            return null;

        return binSearchHelper(key, root);
    }

    //binSearchHelper() - recursive method to conduct binary search
    public TreeNode binSearchHelper(Object key, TreeNode p)
    {
        if (p == null)
            return null;

        Object data = p.item;
        //this is the key, so return the node p
        if (key.equals(data))
            return p;

        //else, key < data, so search left subtree    
        if (((Comparable)key).compareTo((Comparable)data) < 0)
            return binSearchHelper(key, p.left);

        //else, key > data, so search right subtree
        return binSearchHelper(key, p.right);
    }

    //insert() - inserts a new node containing given data according to bin search rules
    public void insert(Object data)
    {
        TreeNode newNode = new TreeNode(data);

        TreeNode curr = root;   // lead node
        TreeNode trail = null;  // train node, should be the leaf node when we reach the end

        //traverse the binary search, keep track of the trail node
        while (curr != null)
        {
            trail = curr;       // catch up trail

            if (((Comparable)data).compareTo((Comparable)curr.item) < 0)
                curr = curr.left;       // if smaller, go left
            else
                curr = curr.right;
        }

        //figure out where the new node goes in relation to the leaf
        if (trail == null)
            root = newNode;
        else if (((Comparable)data).compareTo((Comparable)trail.item) < 0)
            trail.left = newNode;
        else
            trail.right = newNode;
    }

    //remove() - remove node containing data (if found)
    public void remove(Object data)
    {
        TreeNode p = root;
        TreeNode trailP = null;

        //if tree is empty just announce and exit
        if (isEmpty())
        {
            System.out.println("Data not found -- tree is empty");
            return;
        }

        //run binary search protocol to locate data
        while (p != null && !p.item.equals(data))
        {
            trailP = p;
            if (((Comparable)data).compareTo((Comparable)p.item) < 0)
                p = p.left;       // if smaller, go left
            else
                p = p.right;
        }

        //if p is null, we know data is not in tree
        if (p == null)
        {   
            System.out.println("Data not found");
            return;
        }

        // data ws found and is in p; trailP is p's parent
        //case 1:  p is a leaf node
        if (p.left == null && p.right == null)
        {
            //p is the root - list is now empty
            if (p == root)
                root = null;

            //p was trailP's left child
            else if (trailP.left == p)
                trailP.left = null;

            //else p was trailP's right child
            else
                trailP.right = null;
        } 
        //case 2A:  p has 1 (left) child
        else if (p.right == null)
        {
            //p is the root -- then p's left child is the new root
            if (p == root)
                root = p.left;

            //p was trailP's left child
            else if (trailP.left == p)
                trailP.left = p.left;

            //else p was trailP's right child
            else
                trailP.right = p.left;
        }
        //case 2B:  p has 1 (right) child
        else if (p.left == null)
        {
            //p is the root -- then p's right child is the new root
            if (p == root)
                root = p.right;

            //p was trailP's left child
            else if (trailP.left == p)
                trailP.left = p.right;

            //else p was trailP's right child
            else
                trailP.right = p.right;
        }
        //case 3:  p has 2 children
        else
        {
            //find next largest data -- leftmost tree in p's right subtree
            TreeNode q = p.right;
            TreeNode trailQ = p;

            //keep going left as long as q has a left child
            while (q.left != null)
            {
                trailQ = q;
                q = q.left;
            }

            //at this point q is the node containing the next largest value after data
            //swap q and p's data
            p.item = q.item;
            q.item = data;

            //now remove q according to above rules
            if(q.left == null && q.right == null)
                trailQ.left = null;
            else if (q.right == null)
                trailQ.left = q.left;
            else
                trailQ.left = q.right;

        }
    }

    //travInOrder() - recursively traverse binary tree INORDER
    public void travInOrder()
    {
        if (isEmpty())
            System.out.println("Tree is empty");
        else
            travInOrderHelper(root);

        System.out.println();

    }

    public void travInOrderHelper(TreeNode p)
    {
        if (p != null)
        {
            travInOrderHelper(p.left);
            System.out.print(p.item + "\t");
            travInOrderHelper(p.right);
        }
    }

    //treeSort() - Uses a binary search tree to sort the data items in the given array
    //    Returns the sorted array
    public static Object[] treeSort(Object[] data)
    {
        //FILL IN HERE
        //Create new Binary Tree
        BinaryTree newTree = new BinaryTree();
        //Insert each element of array into the binary search tree
        for(int i = 0; i < data.length;i++)
        {
            //Insert element into a binary search tree
            newTree.insert(data);

        }
        //create a new queue
        Queue binQ = new Queue();
        //Add all nodes from newTree into a queue
        treesorthelper(newTree.root,binQ);
        Node front = binQ.front;
        //insert elements of queue into array
        while (binQ.isEmpty() != true)
        {
            data.add(binQ.remove());
            front = front.next;
        }
        return data;

    }
    //HELPER METHOD TO DO THE IN ORDER TRAVERSAL
    public static void treesorthelper(TreeNode p, Queue binQ)
    {

        if (p != null)
        {
            treesorthelper(p.left, binQ);
            binQ.insert(p.item);
            treesorthelper(p.right, binQ);
        }
    }
}
