package Queue;


/**
 * QueueException.java
 * Implementation of a queue-based exception type
 */
public class QueueException extends Exception
{
    public QueueException()
    {
        super("Queue Exception!");
    }
    
    public QueueException(String mes)
    {
        super(mes);
    }
}
