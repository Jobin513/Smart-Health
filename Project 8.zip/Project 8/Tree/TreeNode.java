package Tree;


/**
 * TreeNode.java
 * Implementation of a generalized Node for our Binary Tree
 * 
 * Sung Kim (modified with annotations from Carrano/Prichard)
 */
public class TreeNode
{
    Object item;    //the data item stored in the Node
    TreeNode left;      //pointer to left child
    TreeNode right;     //pointer to right child
    
    //constructor - save data into Node; initialize next to null
    public TreeNode(Object data)
    {
        item = data;
        left = null;
        right = null;
    }
}
