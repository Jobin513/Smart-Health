package Queue;

/**
 * Queue.java
 * Implementation of a reference-based linked queue
 * 
 * Sung Kim (modified from Carrano/Prichard)
 */
public class Queue
{
    private Node front; // first element of the queue
    private Node back;  // last element of the queue

    //constructor - create an empty queue
    public Queue()
    {
        front = null;
        back = null;
    }

    //isEmpty() - return true if queue is empty, false otherwise
    public boolean isEmpty()
    {
        return (front == null);
    }

    //insert() - insert new Node containing data at the back of the queue
    public void insert(Object data)
    {
        //create new Node
        Node newNode = new Node(data);

        //if queue is empty, assign front to new node
        if (isEmpty())
            front = newNode;
        //otherwise, attack new Node after the back node
        else
            back.next = newNode;
            
        //new node is the new back node
        back = newNode;
    }

    //remove() - remove the front Node and return its data item
    public Object remove()
    {
        try{
            //check if empty
            if (isEmpty())
            {
                throw new QueueException();
            }

        } catch (QueueException e)
        {
            System.out.println(e.getMessage() + " Can't remove from empty queue!");
            return null;
        }
        //save the front node
        Node p = front;

        //if only node left, set back node to null
        if (front == back)
            back = null;
            
        //we remove the front node by re-assigning front
        front = front.next;
                
        //return our old front's item
        return p.item;
    }

    //delete() - deletes the contents of entire queue
    public void delete()
    {
        front = null;
        back = null;
    }

}
