
/**
 * TreeDriver.java
 * Sung Kim
 * 
 * Driver class to test generic linked lists
 */
import Tree.*;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;

public class TreeSortDriver
{
    final static int NUM_VALUES = 5000;
    
    public static void main(String[] args) {
        Integer[] data = shuffledArray(NUM_VALUES);
        System.out.println("Initial data:");
        printArray(data);
        
        System.out.println();
        BinaryTree.treeSort(data);      
        
        System.out.println("\n\nFinal data:");
        printArray(data);
        
    }

    //return a shuffled array of size n
    public static Integer[] shuffledArray(int n)
    {
        //create array of integers
        Integer[] array = new Integer[n];

        //fill array with values 1 to n
        for (int i = 0; i < array.length; i++)
            array[i] = i+1;

        List<Integer> l = Arrays.asList(array);
        Collections.shuffle(l);

        return (Integer[])l.toArray(array);

    }

    //print array of integers, 10 elements per line
    public static void printArray(Integer[] array)
    {
        for (int i = 0; i < array.length/10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                System.out.print(array[i*10 + j] + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }

}